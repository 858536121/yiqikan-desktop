/**
 * YiVideo Extension Background Service Worker
 * 1. Restricts all dynamic declarativeNetRequest rules strictly to Yiqikan initiator domains.
 * 2. Completely isolates all non-Yiqikan browsing (never modifies cookies or network requests for external sites like Alipay).
 * 3. Supports silent background verification for video CDN/WAF challenge pages inside Yiqikan rooms.
 */

const YIQIKAN_INITIATOR_DOMAINS = [
  "cpolar.cn",
  "cpolar.top",
  "yiqikan.club",
  "yiqikan.cn",
  "localhost",
  "127.0.0.1",
];

function isYiqikanDomain(domain) {
  if (!domain || typeof domain !== "string") return false;
  const d = domain.toLowerCase().replace(/^\./, "");
  return YIQIKAN_INITIATOR_DOMAINS.some((y) => d === y || d.endsWith(`.${y}`));
}

function isVideoWafCookie(c) {
  if (!c || !c.name) return false;
  const n = c.name.toLowerCase();
  return (
    n.includes("cdn_") ||
    n.includes("cf_") ||
    n.includes("__cf") ||
    n.includes("waf") ||
    n.includes("shield") ||
    n.includes("pow")
  );
}

const isPatchingCookie = new Set();

function patchVideoCookie(cookie) {
  if (!cookie || cookie.sameSite === "no_restriction") return;
  const rawDomain = cookie.domain || "";
  const domain = rawDomain.startsWith(".") ? rawDomain.slice(1) : rawDomain;

  const protocol = cookie.secure ? "https:" : "http:";
  const url = `${protocol}//${domain}${cookie.path || "/"}`;
  const key = `${url}|${cookie.name}`;

  if (isPatchingCookie.has(key)) return;
  isPatchingCookie.add(key);

  const newCookie = {
    url,
    name: cookie.name,
    value: cookie.value,
    path: cookie.path || "/",
    domain: cookie.domain,
    secure: true,
    httpOnly: cookie.httpOnly,
    sameSite: "no_restriction",
    storeId: cookie.storeId,
  };

  if (cookie.expirationDate) {
    newCookie.expirationDate = cookie.expirationDate;
  }

  chrome.cookies.set(newCookie, () => {
    setTimeout(() => isPatchingCookie.delete(key), 800);
  });
}

function syncDynamicCookieRules() {
  chrome.cookies.getAll({}, (cookies) => {
    if (!cookies) return;

    const cookiesByDomain = new Map();
    for (const c of cookies) {
      const rawDomain = c.domain || "";
      const d = rawDomain.startsWith(".") ? rawDomain.slice(1) : rawDomain;

      if (!cookiesByDomain.has(d)) cookiesByDomain.set(d, []);
      cookiesByDomain.get(d).push(`${c.name}=${c.value}`);
    }

    const addRules = [];
    let ruleId = 1000;

    for (const [domain, cookieList] of cookiesByDomain.entries()) {
      const hasShieldCookie = cookieList.some(
        (str) =>
          str.includes("cdn_") ||
          str.includes("cf_") ||
          str.includes("__cf") ||
          str.includes("PHPSESSID") ||
          str.includes("waf_") ||
          str.includes("shield_") ||
          str.includes("pow")
      );

      if (hasShieldCookie) {
        const cookieValue = cookieList.join("; ");
        addRules.push({
          id: ruleId++,
          priority: 5,
          action: {
            type: "modifyHeaders",
            requestHeaders: [
              { header: "cookie", operation: "set", value: cookieValue },
              { header: "referer", operation: "set", value: `https://${domain}/` },
            ],
          },
          condition: {
            urlFilter: `||${domain}`,
            resourceTypes: [
              "sub_frame",
              "stylesheet",
              "script",
              "image",
              "font",
              "media",
              "xmlhttprequest",
              "other",
            ],
            // Strict initiator isolation: ONLY apply when requested by Yiqikan pages
            initiatorDomains: YIQIKAN_INITIATOR_DOMAINS,
          },
        });
      }
    }

    chrome.declarativeNetRequest.getDynamicRules((existingRules) => {
      const removeRuleIds = (existingRules || []).map((r) => r.id);
      chrome.declarativeNetRequest.updateDynamicRules(
        {
          removeRuleIds,
          addRules,
        },
        () => {
          if (chrome.runtime.lastError) {
            console.warn("[YiVideo Extension] Failed to update dynamic rules:", chrome.runtime.lastError);
          } else {
            console.log(`[YiVideo Extension] Synced ${addRules.length} dynamic cookie rules (Strictly isolated to Yiqikan initiator).`);
          }
        }
      );
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  console.log("[YiVideo Extension] Installed successfully with domain isolation.");
  syncDynamicCookieRules();
});

chrome.runtime.onStartup.addListener(() => {
  syncDynamicCookieRules();
});

// ------------------------------------------------------------------
// Silent Background Verification Helper (Auto-Pass Challenge for Video Iframes)
// ------------------------------------------------------------------
const activeVerifyingDomains = new Set();
const domainCooldowns = new Map(); // domain -> cooldownUntilTimestamp
const domainAttempts = new Map();  // domain -> count

function domainsMatch(d1, d2) {
  if (!d1 || !d2) return false;
  const clean1 = d1.toLowerCase().replace(/^\./, "").replace(/^www\./, "");
  const clean2 = d2.toLowerCase().replace(/^\./, "").replace(/^www\./, "");
  return clean1 === clean2 || clean1.endsWith("." + clean2) || clean2.endsWith("." + clean1);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "auto-verify-url" && request.url) {
    let domain = "";
    try {
      domain = new URL(request.url).hostname;
    } catch (_) {
      return;
    }

    const now = Date.now();
    const cooldown = domainCooldowns.get(domain);
    if (cooldown && now < cooldown) {
      console.log(`[YiVideo Extension] Domain ${domain} is on verification cooldown, skipping.`);
      sendResponse({ status: "cooldown" });
      return;
    }

    const attempts = domainAttempts.get(domain) || 0;
    if (attempts >= 2) {
      console.warn(`[YiVideo Extension] Max verification attempts reached for ${domain}. Skipping.`);
      sendResponse({ status: "max_attempts" });
      return;
    }

    if (activeVerifyingDomains.has(domain)) {
      sendResponse({ status: "already_verifying" });
      return;
    }
    activeVerifyingDomains.add(domain);
    domainAttempts.set(domain, attempts + 1);

    console.log(`[YiVideo Extension] Launching silent verification tab for: ${request.url} (Attempt ${attempts + 1})`);

    chrome.tabs.create(
      {
        url: request.url,
        active: false,
      },
      (tab) => {
        if (!tab || !tab.id) {
          activeVerifyingDomains.delete(domain);
          return;
        }

        const tabId = tab.id;
        let resolved = false;
        let isCleanedUp = false;

        const checkCookieListener = (changeInfo) => {
          if (!changeInfo.removed && changeInfo.cookie) {
            const cookieDomain = changeInfo.cookie.domain || "";
            if (domainsMatch(domain, cookieDomain)) {
              if (isVideoWafCookie(changeInfo.cookie)) {
                resolved = true;
                patchVideoCookie(changeInfo.cookie);
                cleanUp(true);
              }
            }
          }
        };

        const tabRemovedListener = (removedTabId) => {
          if (removedTabId === tabId) {
            if (!resolved) {
              console.log(`[YiVideo Extension] Verification tab ${tabId} for ${domain} closed. Stopping verification.`);
              // Put domain on cooldown so user closing the tab immediately stops the loop!
              domainCooldowns.set(domain, Date.now() + 180000); // 3-minute cooldown
              cleanUp(false);
            }
          }
        };

        const cleanUp = (success) => {
          if (isCleanedUp) return;
          isCleanedUp = true;
          clearTimeout(timeoutTimer);
          chrome.cookies.onChanged.removeListener(checkCookieListener);
          chrome.tabs.onRemoved.removeListener(tabRemovedListener);

          if (!success) {
            // Set 2 min cooldown on failure/timeout to prevent repeat tab creation
            domainCooldowns.set(domain, Date.now() + 120000);
            console.warn(`[YiVideo Extension] Verification failed or timed out for ${domain}. Cooldown active.`);
          }

          setTimeout(() => {
            try {
              chrome.tabs.remove(tabId, () => {});
            } catch (_) {}
            activeVerifyingDomains.delete(domain);

            if (success) {
              domainAttempts.delete(domain);
              syncDynamicCookieRules();
              // ONLY notify web rooms to reload if verification actually succeeded
              chrome.tabs.query({}, (tabs) => {
                for (const t of tabs) {
                  if (t.id) {
                    chrome.tabs.sendMessage(t.id, {
                      action: "shield-verification-complete",
                      domain,
                      url: request.url,
                      success: true,
                    }).catch(() => {});
                  }
                }
              });
            }
          }, success ? 1200 : 0);
        };

        chrome.cookies.onChanged.addListener(checkCookieListener);
        chrome.tabs.onRemoved.addListener(tabRemovedListener);

        const timeoutTimer = setTimeout(() => {
          if (!resolved) {
            cleanUp(false);
          }
        }, 12000);
      }
    );

    sendResponse({ status: "verifying_started" });
  }
});
