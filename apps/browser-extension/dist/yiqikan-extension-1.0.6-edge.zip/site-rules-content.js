// Generated from packages/shared/src/site-rules/page-script.ts. Do not edit.
window.__yiqikanInstallSiteRules = function(snapshot) {
(function(snapshot) {
  if (window.__yiqikanSiteRules) return;
  var profile = null, events = [], disabled = false;
  function record(capability, status, reason) {
    var last = events[events.length - 1];
    if (last && last.capability === capability && last.status === status && last.reason === reason) { last.count = Math.min(last.count + 1, 1000000); return; }
    events.push({capability:capability,status:status,reason:reason,count:1});
    if (events.length > 32) events.shift();
  }
  function version(v) { return v.split('.').map(Number); }
  function compare(a,b) { a=version(a); b=version(b); for(var i=0;i<3;i++)if(a[i]!==b[i])return a[i]>b[i]?1:-1; return 0; }
  function matches(rule) {
    try {
      var u = new URL(location.href);
      return /^https?:$/.test(u.protocol) && rule.match.hosts.indexOf(u.hostname)>=0 && rule.match.pathPrefixes.some(function(p){return u.pathname.indexOf(p)===0;});
    } catch (_) { return false; }
  }
  if (snapshot && snapshot.release.enabled && snapshot.release.expiresAt > Date.now()) {
    var rules = snapshot.release.rules.filter(function(r) {
      return r.platforms.indexOf(snapshot.platform)>=0 && compare(snapshot.clientVersion,r.clientVersions.min)>=0
        && compare(snapshot.clientVersion,r.clientVersions.max)<=0 && matches(r);
    }).sort(function(a,b){return b.priority-a.priority;});
    if (rules.length && (rules.length===1 || rules[0].priority!==rules[1].priority)) profile=rules[0];
    else if(rules.length)record('profile','abstain','ambiguous-profile');
  }
  function result(capability,status,reason,value) {
    record(capability,status,reason);
    return {status:status,reason:reason,value:value};
  }
  function canRead(capability) {
    if(disabled || !profile || !matches(profile) || !snapshot || snapshot.release.expiresAt<=Date.now())return false;
    return Boolean(profile.capabilities[capability]);
  }
  function resolved(capability,value) {
    return profile.mode==='active' ? result(capability,'applied','matched',value) : result(capability,'abstain','observe');
  }
  var playback = null;
  function own(value,key) {
    var d=value && typeof value==='object' && Object.getOwnPropertyDescriptor(value,key);
    return d && Object.prototype.hasOwnProperty.call(d,'value') ? d.value : undefined;
  }
  function playbackId(value,c) {
    return typeof value==='string' && value.indexOf(c.idPrefix)===0 && /^[A-Za-z0-9_-]{8,240}$/.test(value.slice(c.idPrefix.length));
  }
  if(profile && profile.capabilities.playbackPage) {
    window.addEventListener(profile.capabilities.playbackPage.event,function(event){
      if(!canRead('playbackPage'))return;
      var c=profile.capabilities.playbackPage,f=c.fields,value=event.detail;
      if(own(value,f.active)!==true){playback=null;return;}
      var id=own(value,f.id);if(!playbackId(id,c)){playback=null;return;}
      var name=own(value,f.title),episode=Number(own(value,f.episode));
      playback={id:id,title:typeof name==='string'?name.replace(/\s+/g,' ').trim().slice(0,300):undefined,
        episode:Number.isInteger(episode)&&episode>0&&episode<1000000?episode:null};
    });
  }
  function playbackPage() {
    if(!canRead('playbackPage'))return {status:'unsupported'};
    try {
      var c=profile.capabilities.playbackPage,u=new URL(location.href);
      if(u.protocol!=='https:' || u.username || u.password)return result('playbackPage','abstain','unsafe-page');
      var privatePage=c.privatePathPrefixes.some(function(p){return u.pathname.indexOf(p)===0;});
      var id=privatePage?playback&&playback.id:u.pathname.indexOf(c.playerPathPrefix)===0?u.pathname.slice(c.playerPathPrefix.length):null;
      if(!playbackId(id,c))return resolved('playbackPage',{privatePage:privatePage});
      var state=playback&&playback.id===id?playback:null;
      var episode=state&&state.episode || Number(u.searchParams.get(c.episodeQuery));
      if(!Number.isInteger(episode)||episode<=0||episode>=1000000)episode=null;
      var route=new URL(c.playerPathPrefix+id,u.origin),identityUrl=route.href;
      if(episode)route.searchParams.set(c.episodeQuery,String(episode));
      var selectedLabel,episodeMetadata;
      // Only an opted-in site profile may replace its numeric fallback label
      // with selected DOM metadata. Ambiguous/oversized queries give no proof.
      if(c.selectedEpisode) {
        var labels=[],scanned=0,valid=true;
        for(var i=0;i<c.selectedEpisode.selectors.length;i++) {
          var nodes=document.querySelectorAll(c.selectedEpisode.selectors[i]);
          scanned+=nodes.length;if(scanned>32){valid=false;break;}
          for(var j=0;j<nodes.length;j++) {
            var label=String(nodes[j].textContent || '').slice(0,2000).replace(/\s+/g,' ').trim();
            if(label.length>c.selectedEpisode.maxChars){valid=false;break;}
            if(label && labels.indexOf(label)<0)labels.push(label);
          }
          if(!valid)break;
        }
        if(valid && labels.length<=1) {
          selectedLabel=labels[0];
          episodeMetadata={positionKey:episode?identityUrl+'|'+episode:undefined,
            selectionKey:selectedLabel?identityUrl+'|'+selectedLabel:undefined};
        }
      }
      return resolved('playbackPage',{privatePage:privatePage,shareUrl:privatePage?route.href:undefined,
        identityUrl:identityUrl,title:state&&state.title||undefined,
        episode:selectedLabel?{label:selectedLabel}:episode?{label:c.episodeLabel.prefix+episode+c.episodeLabel.suffix}:undefined,
        episodeMetadata:episodeMetadata});
    }catch(_){return result('playbackPage','abstain','invalid-metadata');}
  }
  function title() {
    if(!canRead('title'))return {status:'unsupported'};
    try {
      var c=profile.capabilities.title;
      for(var i=0;i<c.selectors.length;i++) {
        var n=document.querySelector(c.selectors[i]);
        var value=n && String(n.textContent || '').slice(0,2000).replace(/\s+/g,' ').trim().slice(0,c.maxChars);
        if(value)return resolved('title',value);
      }
      return result('title','abstain','no-match');
    }catch(_){disabled=true;return result('title','error','query-failed');}
  }
  function mediaCandidates() {
    if(!canRead('mediaCandidates'))return {status:'unsupported'};
    try {
      var c=profile.capabilities.mediaCandidates, nodes=[], scanned=0;
      for(var i=0;i<c.selectors.length;i++) {
        var found=document.querySelectorAll(c.selectors[i]);
        if(scanned+found.length>100)return result('mediaCandidates','abstain','candidate-limit');
        scanned+=found.length;
        for(var j=0;j<found.length;j++) {
          var n=found[j];
          if(!/^(VIDEO|BWP-VIDEO)$/.test(n.tagName) || nodes.indexOf(n)>=0 || !n.isConnected || c.excludeWithin.some(function(s){return Boolean(n.closest(s));}))continue;
          var r=n.getBoundingClientRect(), style=getComputedStyle(n);
          if(r.width>=100 && r.height>=60 && style.visibility!=='hidden' && style.display!=='none' && typeof n.play==='function' && typeof n.pause==='function')nodes.push(n);
        }
      }
      if(nodes.length!==1)return result('mediaCandidates','abstain',nodes.length?'ambiguous-candidate':'no-match');
      return resolved('mediaCandidates',nodes[0]);
    }catch(_){disabled=true;return result('mediaCandidates','error','query-failed');}
  }
  // No setter or remote message listener: this snapshot is pinned to the page.
  window.__yiqikanSiteRules={playbackPage:playbackPage,title:title,mediaCandidates:mediaCandidates,diagnostics:function(){return {
    sequence:snapshot?snapshot.release.sequence:null,ruleId:profile?profile.id:null,ruleVersion:profile?profile.version:null,
    mode:profile?profile.mode:null,disabled:disabled,events:events.map(function(e){return Object.assign({},e);})
  };}};
})(snapshot);
};
(()=>{var h=e=>!!(e&&typeof e=="object"&&!Array.isArray(e));function a(e,i,r=[]){return h(e)&&i.every(s=>Object.hasOwn(e,s))&&Object.keys(e).every(s=>i.includes(s)||r.includes(s))}function l(e,i,r){return Number.isSafeInteger(e)&&e>=i&&e<=r}function o(e,i,r,s){return Array.isArray(e)&&e.length>=i&&e.length<=r&&e.every(t=>typeof t=="string"&&s(t))&&new Set(e).size===e.length}function f(e){return typeof e=="string"&&/^\d{1,5}\.\d{1,5}\.\d{1,5}$/.test(e)}function x(e,i){let r=e.split(".").map(Number),s=i.split(".").map(Number);for(let t=0;t<3;t++)if(r[t]!==s[t])return r[t]>s[t]?1:-1;return 0}function u(e){if(e.length<1||e.length>200||e.trim()!==e)return!1;let i='(?:[a-zA-Z][a-zA-Z0-9-]*)?(?:[.#][a-zA-Z_][a-zA-Z0-9_-]*|\\[[a-zA-Z_][a-zA-Z0-9_-]*(?:="[a-zA-Z0-9_-]+")?\\])*';return new RegExp("^"+i+"(?:(?: +| *> *)"+i+")*$").test(e)&&!/(^|[ >])([ >]|$)/.test(e.replace(/ *> */g,">"))}function b(e){return e.length<=253&&/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(e)&&e.split(".").every(i=>i.length<=63)}function m(e){if(!a(e,["schemaVersion","id","version","engineMajor","platforms","clientVersions","priority","match","mode","capabilities"])||!(e.schemaVersion===1&&e.engineMajor===1||e.schemaVersion===2&&e.engineMajor===2)||typeof e.id!="string"||!/^[a-z][a-z0-9-]{0,63}$/.test(e.id)||!l(e.version,1,Number.MAX_SAFE_INTEGER)||!l(e.priority,0,1e3)||!["observe","active"].includes(e.mode)||!o(e.platforms,1,3,t=>["ios","android","extension"].includes(t))||!a(e.clientVersions,["min","max"])||!f(e.clientVersions.min)||!f(e.clientVersions.max)||x(e.clientVersions.min,e.clientVersions.max)>0||!a(e.match,["hosts","pathPrefixes"])||!o(e.match.hosts,1,8,b)||!o(e.match.pathPrefixes,1,8,t=>t.length<=160&&/^\/[a-zA-Z0-9/_-]*$/.test(t)&&!t.includes("//"))||!a(e.capabilities,[],e.schemaVersion===1?["title","mediaCandidates"]:["title","mediaCandidates","playbackPage"])||!Object.keys(e.capabilities).length)return!1;let{title:i,mediaCandidates:r,playbackPage:s}=e.capabilities;if(s!==void 0){let t=s,p=n=>typeof n=="string"&&/^[a-zA-Z][a-zA-Z0-9_]{0,63}$/.test(n)&&!["constructor","prototype","__proto__"].includes(n),d=n=>n.length<=160&&/^\/[a-zA-Z0-9/_-]+\/$/.test(n)&&!n.includes("//");if(!a(t,["event","fields","idPrefix","privatePathPrefixes","playerPathPrefix","episodeQuery","episodeLabel"],["selectedEpisode"])||typeof t.event!="string"||!/^[a-zA-Z][a-zA-Z0-9:_-]{0,79}$/.test(t.event)||!a(t.fields,["active","id","title","episode"])||!Object.values(t.fields).every(p)||typeof t.idPrefix!="string"||!/^[a-zA-Z][a-zA-Z0-9_-]{0,15}$/.test(t.idPrefix)||!o(t.privatePathPrefixes,1,8,d)||typeof t.playerPathPrefix!="string"||!d(t.playerPathPrefix)||!p(t.episodeQuery)||!a(t.episodeLabel,["prefix","suffix"])||!Object.values(t.episodeLabel).every(n=>typeof n=="string"&&n.length<=20&&!/[<>\u0000-\u001f]/.test(n))||t.selectedEpisode!==void 0&&(!a(t.selectedEpisode,["selectors","maxChars"])||!o(t.selectedEpisode.selectors,1,8,u)||!l(t.selectedEpisode.maxChars,1,120)))return!1}return!(i!==void 0&&(!a(i,["selectors","maxChars"])||!o(i.selectors,1,8,u)||!l(i.maxChars,1,300))||r!==void 0&&(!a(r,["selectors","excludeWithin"])||!o(r.selectors,1,8,u)||!o(r.excludeWithin,0,8,u)))}var c=[{schemaVersion:2,id:"kanju-search-playback",version:2,engineMajor:2,platforms:["ios","android","extension"],clientVersions:{min:"1.0.0",max:"99.99.99"},priority:30,match:{hosts:["kanju.ai","kanju36.com","kanju70.com"],pathPrefixes:["/"]},mode:"active",capabilities:{playbackPage:{event:"movie-search-playback-session-updated",fields:{active:"active",id:"variantId",title:"title",episode:"episode"},idPrefix:"av_",privatePathPrefixes:["/session/"],playerPathPrefix:"/player/",episodeQuery:"episode",episodeLabel:{prefix:"\u7B2C",suffix:"\u96C6"},selectedEpisode:{selectors:[".movie-episode-quick-tab.movie-button-primary",".movie-episode-grid button.movie-button-primary"],maxChars:120}}}}];function g(e,i){if(!c.every(m))throw Error("Invalid bundled site rule");let r=Date.now();return{platform:e,clientVersion:i,release:{schemaVersion:1,sequence:1,issuedAt:r,expiresAt:r+864e5,enabled:!0,rules:JSON.parse(JSON.stringify(c))}}}var k=Object.freeze({});Object.assign(window,{__yiqikanPackagedSiteRuleSnapshot:e=>g("extension",e)});})();
